//
//  MenuCell.swift
//  collectiondemo
//
//  Created by Essam Mahmoud fathy on 2/3/19.
//  Copyright © 2019 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class MenuCell: UICollectionViewCell {
    
    @IBOutlet weak var tabName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        tabName.alpha = 0.6
        
    }
    func setupcell(text: String){
        tabName.text = text
        
    }
    override var isSelected: Bool{
        didSet{
            tabName.alpha = isSelected ? 1.0 : 0.6
        }
    }
}
