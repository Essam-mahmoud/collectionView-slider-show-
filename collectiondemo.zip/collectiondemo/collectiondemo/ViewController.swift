//
//  ViewController.swift
//  collectiondemo
//
//  Created by Essam Mahmoud fathy on 2/3/19.
//  Copyright © 2019 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var collectionView: UICollectionView!
    let countrayArray = [["china","jaban","tiwan"],
                         ["Egypt","tunis","libya"],
                         ["spain","france","italy"]]
    var selectedArray = [String]()
    let menuTitles = ["Asia","Africa","Europe"]
    var selectedIndex = 0
    let indicatorView = UIView()
    let indicatorHight : CGFloat = 3
    var selectedIndexPath = IndexPath(item: 0, section: 0)
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.tableFooterView = UIView()
        selectedArray = countrayArray[selectedIndex]
        collectionView.selectItem(at: selectedIndexPath, animated: false, scrollPosition: .centeredVertically)
        let leftSwip = UISwipeGestureRecognizer(target: self, action: #selector(swipMovement))
        leftSwip.direction = .left
        self.view.addGestureRecognizer(leftSwip)
        let rightSwip = UISwipeGestureRecognizer(target: self, action: #selector(swipMovement))
        rightSwip.direction = .right
        self.view.addGestureRecognizer(rightSwip)
        indicatorView.backgroundColor = UIColor.white
        indicatorView.frame = CGRect(x: collectionView.bounds.minX, y: collectionView.bounds.maxY - indicatorHight, width: collectionView.bounds.width/CGFloat(menuTitles.count), height: indicatorHight)
        collectionView.addSubview(indicatorView)
    }
    @objc func swipMovement(_ sender: UISwipeGestureRecognizer){
        if sender.direction == .left{
            if selectedIndex < menuTitles.count - 1{
                selectedIndex += 1
            }
        }else{
            if selectedIndex > 0{
                selectedIndex -= 1
            }
        }
        selectedIndexPath = IndexPath(item: selectedIndex, section: 0)
        collectionView.selectItem(at: selectedIndexPath, animated: true, scrollPosition: .centeredVertically)
        refreshContent()
        
    }
    
    func refreshContent(){
        selectedArray = countrayArray[selectedIndex]
        tableview.reloadData()
        let desiredX = (collectionView.bounds.width/CGFloat(menuTitles.count)) * CGFloat(selectedIndex)
        UIView.animate(withDuration: 0.3) {
            self.indicatorView.frame = CGRect(x: desiredX, y: self.collectionView.bounds.maxY - self.indicatorHight, width: self.collectionView.bounds.width/CGFloat(self.menuTitles.count), height: self.indicatorHight)
        }
    }
}



extension ViewController : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = selectedArray[indexPath.row]
        return cell
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menuTitles.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MenuCell", for: indexPath) as! MenuCell
        cell.setupcell(text: menuTitles[indexPath.row])
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width/CGFloat(menuTitles.count), height: collectionView.bounds.height)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.item
        refreshContent()
    }
    
}

